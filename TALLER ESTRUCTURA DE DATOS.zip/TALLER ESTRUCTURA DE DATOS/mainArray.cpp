#include <iostream>
#include <string>
#include "vector.h"
using namespace std;

void cargarVectorDeVectores(vector v[], int n);
void generarMatriz(vector v[], vector m[][MAX], int n);
void mostrarVectorDeVectores(vector v[], int n);
void mostrarMatriz(vector m[][MAX], int n);


int main() {
   int tamanio;
    vector vec[MAX];
    vector matriz[MAX][MAX];

    do
    {
        
        cout << "ingrese el tamanio.- ";
        cin >> tamanio;

    } while ((tamanio <=0) || (tamanio > MAX));
    cargarVectorDeVectores(vec, tamanio);
    generarMatriz(vec, matriz, tamanio);
    mostrarVectorDeVectores(vec, tamanio);
    mostrarMatriz(matriz, tamanio);

return 0;
}

void cargarVectorDeVectores(vector v[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "Cargando vector [" << i << "]:" << endl;
        v[i].cargar(n);
    }
}

void generarMatriz(vector v[], vector m[][MAX], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            m[i][j] = v[i]; // Asignar el vector v[i] a la posición (i, j) de la matriz
        }
    }
}

void mostrarVectorDeVectores(vector v[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "Vector [" << i << "]:" << endl;
        v[i].mostrar();
    }
}

void mostrarMatriz(vector m[][MAX], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Elemento (" << i + 1 << "," << j + 1 << "):" << endl;
            m[i][j].mostrar();
        }
    }
}
