#include "vector.h"

vector::vector() {
    n = 0;
}

vector::~vector() {
   
}

void vector::cargar(int tam) {
  
   n = tam; //modificando el atributo de la clase que afecta al objeto
   for(int i = 0; i < n; i++){
       cout << "elemento[" << i << "]: ";
       cin >> date[i];
   }
}

void vector::mostrar() {
  
   cout << "[ ";
for (int i = 0; i < n; i++) {
cout << date[i];
if (i < n - 1) {
cout << " ";
}
}
cout << " ]";

}

void vector::setdate(int pos, string valor) {
   
    date[pos] = valor;

}

string vector::getdate(int pos) const {
   
    return date[pos];

}

void vector::setN(int tam) {
  
    n = tam;
}

int vector::getN() const {
   
    return n;
}
