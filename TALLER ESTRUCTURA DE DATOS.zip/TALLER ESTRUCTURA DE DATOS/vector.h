#pragma once
#define MAX 10
#include <iostream>
#include <string>
using namespace std;

class vector
{

    private: 
        string date[MAX];
        int n;
    public:
        vector();
        ~vector();
        void cargar(int tam);
        void mostrar();
        void setdate(int pos, string valor);
        string getdate(int pos) const;
        void setN(int tam);
        int getN() const;
};